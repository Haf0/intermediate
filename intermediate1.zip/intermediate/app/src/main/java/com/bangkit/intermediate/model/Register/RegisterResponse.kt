package com.bangkit.intermediate.model.Register

data class RegisterResponse(
    val error :Boolean,
    val message : String
)
